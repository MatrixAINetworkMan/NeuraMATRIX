// Moved to root of objectivec directory, shim to keep anyone's imports working.
#import "GPBFieldMask.pbobjc.h"
